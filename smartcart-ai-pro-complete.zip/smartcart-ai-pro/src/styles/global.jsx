// Global styles injected as CSS
const style = document.createElement('style');
style.textContent = `
  /* Design System */
  :root {
    --bg-primary: #ffffff;
    --bg-secondary: #f5f5f5;
    --color-primary: #2874f0;
    --color-accent: #ff6d00;
    --text-primary: #212121;
    --text-secondary: #717171;
    --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.1);
    --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.1);
    --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.1);
    --border-radius: 8px;
    --transition: all 0.3s ease;
  }

  /* Dark Mode */
  body.dark-mode {
    --bg-primary: #1a1a1a;
    --bg-secondary: #2d2d2d;
    --text-primary: #ffffff;
    --text-secondary: #b0b0b0;
  }

  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  html {
    scroll-behavior: smooth;
  }

  body {
    font-family: 'Poppins', sans-serif;
    background-color: var(--bg-primary);
    color: var(--text-primary);
    line-height: 1.6;
    transition: var(--transition);
  }

  h1, h2, h3, h4, h5, h6 {
    font-weight: 600;
    line-height: 1.2;
    margin-bottom: 0.5rem;
  }

  h1 { font-size: 2.5rem; }
  h2 { font-size: 2rem; }
  h3 { font-size: 1.5rem; }
  h4 { font-size: 1.25rem; }

  p {
    color: var(--text-secondary);
    margin-bottom: 1rem;
  }

  a {
    color: var(--color-primary);
    text-decoration: none;
    transition: var(--transition);
  }

  a:hover {
    color: var(--color-accent);
  }

  button {
    font-family: 'Poppins', sans-serif;
    cursor: pointer;
    border: none;
    border-radius: var(--border-radius);
    transition: var(--transition);
    font-weight: 500;
  }

  .btn {
    padding: 0.75rem 1.5rem;
    font-size: 1rem;
    border-radius: var(--border-radius);
    transition: var(--transition);
    font-weight: 500;
    cursor: pointer;
    border: none;
  }

  .btn-primary {
    background-color: var(--color-primary);
    color: white;
  }

  .btn-primary:hover {
    background-color: #1d4ed8;
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
  }

  .btn-secondary {
    background-color: var(--bg-secondary);
    color: var(--text-primary);
    border: 1px solid #ddd;
  }

  .btn-secondary:hover {
    background-color: #e8e8e8;
    transform: translateY(-2px);
  }

  body.dark-mode .btn-secondary {
    border-color: #444;
  }

  body.dark-mode .btn-secondary:hover {
    background-color: #3d3d3d;
  }

  .btn-accent {
    background-color: var(--color-accent);
    color: white;
  }

  .btn-accent:hover {
    background-color: #e55a00;
    transform: translateY(-2px);
    box-shadow: var(--shadow-md);
  }

  .btn-sm {
    padding: 0.5rem 1rem;
    font-size: 0.875rem;
  }

  .btn-lg {
    padding: 1rem 2rem;
    font-size: 1.125rem;
  }

  input, textarea, select {
    font-family: 'Poppins', sans-serif;
    padding: 0.75rem;
    border: 1px solid #ddd;
    border-radius: var(--border-radius);
    font-size: 1rem;
    transition: var(--transition);
    width: 100%;
    background-color: var(--bg-primary);
    color: var(--text-primary);
  }

  body.dark-mode input,
  body.dark-mode textarea,
  body.dark-mode select {
    border-color: #444;
  }

  input:focus, textarea:focus, select:focus {
    outline: none;
    border-color: var(--color-primary);
    box-shadow: 0 0 0 3px rgba(40, 116, 240, 0.1);
  }

  label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: var(--text-primary);
  }

  .form-group {
    margin-bottom: 1.5rem;
  }

  .container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1rem;
  }

  .flex {
    display: flex;
  }

  .flex-center {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .flex-between {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .grid {
    display: grid;
  }

  .grid-2 {
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
  }

  .grid-3 {
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
  }

  .grid-4 {
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
  }

  .card {
    background-color: var(--bg-primary);
    border-radius: var(--border-radius);
    box-shadow: var(--shadow-sm);
    padding: 1.5rem;
    transition: var(--transition);
  }

  .card:hover {
    box-shadow: var(--shadow-md);
    transform: translateY(-4px);
  }

  .badge {
    display: inline-block;
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .badge-primary {
    background-color: rgba(40, 116, 240, 0.1);
    color: var(--color-primary);
  }

  .badge-accent {
    background-color: rgba(255, 109, 0, 0.1);
    color: var(--color-accent);
  }

  .badge-success {
    background-color: rgba(76, 175, 80, 0.1);
    color: #4caf50;
  }

  .mt-1 { margin-top: 0.5rem; }
  .mt-2 { margin-top: 1rem; }
  .mt-3 { margin-top: 1.5rem; }
  .mt-4 { margin-top: 2rem; }

  .mb-1 { margin-bottom: 0.5rem; }
  .mb-2 { margin-bottom: 1rem; }
  .mb-3 { margin-bottom: 1.5rem; }
  .mb-4 { margin-bottom: 2rem; }

  .p-1 { padding: 0.5rem; }
  .p-2 { padding: 1rem; }
  .p-3 { padding: 1.5rem; }
  .p-4 { padding: 2rem; }

  @media (max-width: 768px) {
    h1 { font-size: 2rem; }
    h2 { font-size: 1.5rem; }
    h3 { font-size: 1.25rem; }

    .grid-2 { grid-template-columns: 1fr; }
    .grid-3 { grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); }
    .grid-4 { grid-template-columns: repeat(2, 1fr); }
  }

  @media (max-width: 480px) {
    .container { padding: 0 0.75rem; }
    .grid-2, .grid-3, .grid-4 { grid-template-columns: 1fr; gap: 1rem; }
    .btn { padding: 0.625rem 1.25rem; font-size: 0.875rem; }
  }
`;
document.head.appendChild(style);
