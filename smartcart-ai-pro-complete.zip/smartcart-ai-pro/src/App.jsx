import React from 'react';
import { Routes, Route, HashRouter, Navigate } from 'react-router-dom';
import { AppProvider } from './context/AppContext.jsx';
import Toast from './components/Toast.jsx';
import AIChatbot from './components/AIChatbot.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';

// Pages
import Login from './pages/Login.jsx';
import Signup from './pages/Signup.jsx';
import Home from './pages/Home.jsx';
import Products from './pages/Products.jsx';
import Cart from './pages/Cart.jsx';
import Wishlist from './pages/Wishlist.jsx';
import Tracking from './pages/Tracking.jsx';
import Settings from './pages/Settings.jsx';

function App() {
  return (
    <AppProvider>
      <HashRouter>
        <Toast />
        <AIChatbot />
        <Routes>
          {/* Auth Routes */}
          <Route
            path="/login"
            element={
              localStorage.getItem('isLoggedIn') === 'true'
                ? <Navigate to="/home" replace />
                : <Login />
            }
          />
          <Route path="/signup" element={<Signup />} />

          {/* Protected Routes */}
          <Route path="/" element={<ProtectedRoute element={<Home />} />} />
          <Route path="/home" element={<ProtectedRoute element={<Home />} />} />
          <Route path="/products" element={<ProtectedRoute element={<Products />} />} />
          <Route path="/cart" element={<ProtectedRoute element={<Cart />} />} />
          <Route path="/wishlist" element={<ProtectedRoute element={<Wishlist />} />} />
          <Route path="/tracking" element={<ProtectedRoute element={<Tracking />} />} />
          <Route path="/settings" element={<ProtectedRoute element={<Settings />} />} />

          {/* Catch-all */}
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </HashRouter>
    </AppProvider>
  );
}

export default App;
