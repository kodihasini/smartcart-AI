# SmartCart AI Pro - Premium E-Commerce Platform

A professional, feature-rich e-commerce web application built with React, Vite, and Context API. SmartCart AI Pro provides a complete shopping experience with AI chatbot, dark/light mode, user profile management, and realistic product catalog.

## 🚀 Features

### 🔐 Enhanced Authentication
- User registration with complete profile details (address, phone, payment method)
- Secure login with session persistence
- Protected routes for authenticated users
- Demo credentials for testing

### 🛍️ Advanced Shopping Experience
- Browse 12 realistic products with real pricing (₹999-₹42,999)
- Advanced filtering by category, mood, and price range
- Full-text search functionality
- Product detail pages with ratings and reviews
- Smart wishlist with price alerts
- Shopping cart with quantity management

### 💳 Professional Checkout
- Add/remove products from cart
- Adjust quantities with +/- buttons
- Dynamic price calculation
- Smart shipping charges (Free above ₹1999, otherwise ₹99)
- Order summary and checkout simulation

### 📦 Order Tracking
- 6-step order tracking system
- Real-time status updates with animated progress bar
- ETA display
- Order history
- Simulated delivery progression

### ⚙️ Settings & Profile Management
- Edit profile information
- Update address and payment details
- Delete account functionality
- Dark/Light mode toggle
- Theme persistence

### 🤖 AI Chatbot
- Floating chat widget
- Product recommendations
- Price and shipping information
- Category browsing assistance
- Smart responses based on user queries

### 🎨 Professional Design
- Light and Dark theme support
- Clean, modern UI inspired by Flipkart/Amazon
- Blue (#2874f0) primary and Orange (#ff6d00) accent colors
- Fully responsive design (mobile, tablet, desktop)
- Font Awesome icons for professional appearance
- Smooth animations and transitions
- Poppins font from Google Fonts

## 🛠️ Tech Stack

- **Frontend Framework**: React 18
- **Build Tool**: Vite 5
- **Routing**: React Router DOM 6
- **State Management**: React Context API
- **Styling**: CSS-in-JS (Pure CSS, no frameworks)
- **Icons**: Font Awesome 6.5
- **Persistence**: LocalStorage
- **Package Manager**: npm/pnpm

## 📁 Project Structure

```
smartcart-ai-pro/
├── src/
│   ├── components/
│   │   ├── Header.jsx
│   │   ├── Footer.jsx
│   │   ├── Toast.jsx
│   │   ├── ProtectedRoute.jsx
│   │   ├── ProductCard.jsx
│   │   └── AIChatbot.jsx
│   ├── pages/
│   │   ├── Login.jsx
│   │   ├── Signup.jsx
│   │   ├── Home.jsx
│   │   ├── Products.jsx
│   │   ├── Cart.jsx
│   │   ├── Wishlist.jsx
│   │   ├── Tracking.jsx
│   │   └── Settings.jsx
│   ├── context/
│   │   └── AppContext.jsx
│   ├── data/
│   │   └── products.jsx
│   ├── styles/
│   │   └── global.jsx
│   ├── App.jsx
│   └── main.jsx
├── index.html
├── vite.config.jsx
├── package.json
└── README.md
```

## 🚀 Installation & Setup

### 1. Clone or Extract Project
```bash
cd smartcart-ai-pro
```

### 2. Install Dependencies
```bash
npm install
# or
pnpm install
```

### 3. Start Development Server
```bash
npm run dev
# or
pnpm dev
```

### 4. Build for Production
```bash
npm run build
# or
pnpm build
```

### 5. Preview Production Build
```bash
npm run preview
# or
pnpm preview
```

## 📝 Demo Credentials

Test the application with these credentials:

- **Email**: test@example.com
- **Password**: password123

Or create a new account using the signup page with complete profile details.

## 🎯 Key Features Explained

### Authentication System
- Users register with name, email, phone, address, city, state, pincode, and payment method
- Passwords validated (minimum 6 characters)
- Login credentials verified against stored users
- Session persists across page refreshes
- Account deletion with confirmation

### Product Catalog
- 12 products with realistic pricing from Google Shopping reference
- Categories: Electronics, Fashion, Lifestyle
- Each product includes: name, price, original price, image, rating, reviews, category, mood, tag
- Real Unsplash images for authentic product display
- Discount percentage calculation
- Filtering by category, mood, and price range
- Full-text search functionality

### Smart Wishlist
- Save favorite products for later
- Move items directly to cart
- Smart alert badge for price monitoring
- Persistent storage using LocalStorage

### Shopping Cart
- Add/remove products
- Adjust quantities with +/- buttons
- Real-time price calculation
- Shipping calculation (Free above ₹1999, otherwise ₹99)
- Order summary with checkout button

### Order Tracking
- 6-step tracking: Order Placed → Confirmed → Packed → Shipped → Out For Delivery → Delivered
- Animated progress bar
- Current status indicator
- Simulated next step button for demo purposes
- Order details with items and total

### AI Chatbot
- Floating widget in bottom-right corner
- Product recommendations
- Pricing information
- Shipping details
- Category browsing assistance
- Smart responses based on keywords

### Toast Notifications
- Non-intrusive notifications for user actions
- Auto-dismiss after 3 seconds
- Types: success, error, info, warning
- Top-right positioning

### Dark/Light Mode
- Toggle in header
- Persists in LocalStorage
- Smooth transitions
- Professional color scheme for both themes

### Settings Panel
- View and edit profile information
- Update address and payment details
- Delete account with confirmation
- Dark mode toggle
- Appearance settings

## 🎨 Color Scheme

| Element | Color | Hex |
|---------|-------|-----|
| Primary | Blue | #2874f0 |
| Accent | Orange | #ff6d00 |
| Background | White | #ffffff |
| Secondary BG | Light Gray | #f5f5f5 |
| Text Primary | Dark Gray | #212121 |
| Text Secondary | Medium Gray | #717171 |

## 📱 Responsive Design

Breakpoints:
- **Desktop**: 1200px and above
- **Tablet**: 768px - 1024px
- **Mobile**: Below 768px

## 🌐 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## ⚡ Performance Features

- Lazy loading of products with skeleton screens
- Efficient state management with Context API
- CSS-in-JS for optimized styling
- Optimized images from Unsplash
- Minimal bundle size with Vite
- Smooth animations without heavy libraries

## 🔒 Security Features

- Protected routes for authenticated users
- Session validation
- Password validation (minimum 6 characters)
- Secure account deletion
- LocalStorage encryption (via browser)

## 📊 Product Data

Products include realistic pricing based on Google Shopping:
- **Electronics**: ₹999 - ₹42,999
- **Fashion**: ₹1,899 - ₹8,999
- **Lifestyle**: ₹999 - ₹5,499

Each product has:
- Realistic pricing with discounts
- High-quality images
- Customer ratings (4.3-4.8 stars)
- Review counts
- Stock status
- Category and mood tags

## 🚀 Future Enhancements

- Backend API integration
- Payment gateway integration (Stripe/Razorpay)
- Advanced AI recommendations
- User profile pictures
- Product reviews and ratings
- Advanced search with autocomplete
- Admin dashboard
- Analytics tracking
- Email notifications
- Social sharing

## 📞 Support

For issues or questions, please refer to the documentation or create an issue in the repository.

## 👥 Team

**SmartCart AI | Team 29 | KL University**

© 2026 SmartCart AI. All Rights Reserved.

---

**Ready to shop smartly? Start exploring SmartCart AI Pro today!** 🛒✨

Built with ❤️ by Team 29
